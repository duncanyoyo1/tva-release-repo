# -*- coding: utf-8 -*-
"""
    IMDB Trailers Kodi Addon
    Copyright (C) 2018 gujal
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# Imports
import re
import sys
import urlparse
import urllib
import urllib2
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import HTMLParser
from BeautifulSoup import BeautifulSoup, SoupStrainer

try:
    import StorageServer
except:
    import storageserverdummy as StorageServer


# DEBUG
DEBUG = False

_addon = xbmcaddon.Addon()
_plugin = _addon.getAddonInfo('name')
_version = _addon.getAddonInfo('version')
_icon = _addon.getAddonInfo('icon')
_fanart = _addon.getAddonInfo('fanart')
_language = _addon.getLocalizedString
_settings = _addon.getSetting
view_modes = [51,53,54,50]

cache = StorageServer.StorageServer('imdbtrailers', _settings('timeout'))
view_mode = view_modes[int(_settings('view_mode'))]
CONTENT_URL = 'https://www.imdb.com/trailers'
DETAILS_PAGE = "https://m.imdb.com/videoplayer/%s"
USER_AGENT = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.57 Safari/537.17'


class Main:
  def __init__(self):
    if ('action=list' in sys.argv[2]):
        self.list_contents()
    elif ('action=play' in sys.argv[2]):
        self.play()
    elif ('action=clear' in sys.argv[2]):
        self.clear_cache()
    else:
        self.main_menu()


  def main_menu(self):
    if DEBUG:
        self.log('main_menu()')
    category = [{'title':_language(30201), 'key':'popTab'},
                {'title':_language(30202), 'key':'recAddTab'},
                {'title':_language(30203), 'key':'tvTab'},
                {'title':_language(30204), 'key':'cache'}]
    for i in category:
        listitem = xbmcgui.ListItem(i['title'])
        listitem.setArt({'thumb': _icon,
                         'fanart': _fanart,
                         'icon' : _icon})

        if i['key'] == 'cache':
            url = sys.argv[0] + '?' + urllib.urlencode({'action': 'clear'})
        else:
            url = sys.argv[0] + '?' + urllib.urlencode({'action': 'list',
                                                        'key': i['key']})
        xbmcplugin.addDirectoryItems(int(sys.argv[1]), [(url, listitem, True)])
    
    # Sort methods and content type...
    xbmcplugin.addSortMethod(handle=int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.setContent(int(sys.argv[1]), 'addons')
    xbmc.executebuiltin('Container.SetViewMode(500)')
    # End of directory...
    xbmcplugin.endOfDirectory(int(sys.argv[1]), True)


  def clear_cache(self):
    """
    Clear the cache database.
    """
    msg = 'Cached Data has been cleared'
    cache.table_name = 'imdbtrailers'
    cache.cacheDelete('%fetch%')
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(_plugin, msg, 3000, _icon))
    
    
  def list_contents(self):
    if DEBUG:
        self.log('content_list()')
    videos,jdata = cache.cacheFunction(fetchdata,self.parameters('key'))
    h = HTMLParser.HTMLParser()
    for video in videos:
        videoId = video.get('data-videoid')
        jd = jdata[videoId]
      
        plot = h.unescape(jd['description'])
        director = jd['directorNames']
        cast = jd['starNames']
        title = jd['titleName']
        tname = jd['trailerName']
        imdb = jd['titleId']
        fanart = jd['slateUrl'].split('_')[0] + 'jpg'
        poster = jd['posterUrl'].split('_')[0] + 'jpg'
        icon = jd['posterUrl']
        try:
            duration = jd['trailerLength']
        except:
            duration = 0

        try:
            tyear = jd['titleNameWithYear']
            year = int(re.findall('\((\d{4})',tyear)[0])
        except:
            year = 1900

        listitem = xbmcgui.ListItem(title)
        listitem.setArt({'thumb': poster,
                         'icon' : icon,
                         'poster': poster,
                         'fanart': fanart})

        listitem.setInfo(type='video',
                         infoLabels={'title': title,
                                     'originaltitle': tname,
                                     'plot': plot,
                                     'year': year,
                                     'duration': duration,
                                     'imdbnumber': imdb,
                                     'director': director,
                                     'cast': cast})

        listitem.setProperty('IsPlayable', 'true')
        url = sys.argv[0] + '?' + urllib.urlencode({'action': 'play',
                                                    'videoid': videoId})
        xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, False)

    # Sort methods and content type...
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_TITLE)
    xbmc.executebuiltin('Container.SetViewMode({})'.format(view_mode))
    # End of directory...
    xbmcplugin.endOfDirectory(int(sys.argv[1]), True)


  def get_video_url(self):
    if DEBUG:
      self.log('get_video_url()')
    quality = _settings("video_quality")
    detailsUrl = DETAILS_PAGE % (self.parameters('videoid'))
    if DEBUG:
      self.log('detailsURL: %s' % detailsUrl)
    details = fetch(detailsUrl)
    v = re.match('definition":"%s".+?Url":"([^"]+)'%quality, details)
    if v:
        videoUrl = v.group(1)
    else:
        videoUrl = re.findall('definition":"\d+p".+?Url":"([^"]+)', details)[0]
    if DEBUG:
      self.log('videoURL: %s' % videoUrl)
    videoUrl = videoUrl.replace('\u002F','/')
    return videoUrl


  def play(self):
    if DEBUG:
      self.log('play()')
    title = unicode(xbmc.getInfoLabel("ListItem.Title"), "utf-8")
    thumbnail = xbmc.getInfoImage("ListItem.Thumb")
    plot = unicode(xbmc.getInfoLabel("ListItem.Plot"), "utf-8")
    # only need to add label, icon and thumbnail, setInfo() and addSortMethod() takes care of label2
    listitem = xbmcgui.ListItem(title)
    listitem.setArt({ 'thumb': thumbnail })

    # set the key information
    listitem.setInfo('video', {'title': title,
                               'label': title,
                               'plot': plot,
                               'plotOutline': plot})

    listitem.setPath(self.get_video_url())
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=listitem)


  def parameters(self, arg):
    _parameters = urlparse.parse_qs(urlparse.urlparse(sys.argv[2]).query)
    return _parameters[arg][0]


  def log(self, description):
    xbmc.log("[ADD-ON] '%s v%s': %s" % (_plugin, _version, description), xbmc.LOGNOTICE)


def fetch(url):

    headers = {'User-Agent': USER_AGENT}
    req = urllib2.Request(url, None, headers)
    data = urllib2.urlopen(req).read()
    return data


def fetchdata(key):

    html = cache.cacheFunction(fetch,CONTENT_URL)
    tlink = SoupStrainer('div', {'id':key})
    jlink = SoupStrainer('script', {'id':'imdbTrailerJson'})
    tabclass = BeautifulSoup(html, parseOnlyThese=tlink)
    jdata = BeautifulSoup(html, parseOnlyThese=jlink)
    items = tabclass.findAll('div', {'class':re.compile('^gridlist-item')})
    jd = json.loads(jdata.text)    
    return items,jd

    
if __name__ == '__main__':
  Main()
